function criptar(){
  var texto = document.getElementById("encriptar1").value;
  var criptar= texto.replace(/e/gi, 'enter').replace(/i/gi, 'imes').replace(/a/gi, 'ai').replace(/o/gi, 'ober').replace(/u/gi, 'ufat');

  var resultado = document.getElementById("encriptado");
  var ResultadoEncriptado = "O Resultado é   =  " + criptar;
  resultado.innerHTML = ResultadoEncriptado;  
  console.log(ResultadoEncriptado)
  }

function descriptar(){
  var texto = document.getElementById("descriptar1").value;
  var descriptar= texto.replace(/enter/gi, 'e').replace(/imes/gi, 'i').replace(/ai/gi, 'a').replace(/ober/gi, 'o').replace(/ufat/gi, 'u');
  
  var resultado = document.getElementById("descriptado");
  var ResultadoDescriptado = "O Resultado é   =  " + descriptar;
  resultado.innerHTML = ResultadoDescriptado;  
  console.log(ResultadoDescriptado)
}



